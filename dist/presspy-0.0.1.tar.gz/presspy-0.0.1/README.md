# PressPy

A Python compression software.